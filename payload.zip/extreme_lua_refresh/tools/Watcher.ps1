# Extreme Lua Refresh - Windows PowerShell 5.1+ development watcher.
# Monitors addons under garrysmod/addons; snapshots Lua and supported web assets.
$ErrorActionPreference = 'Stop'
$AddonRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Addons = (Resolve-Path (Join-Path $AddonRoot '..')).Path
$GMod = (Resolve-Path (Join-Path $Addons '..')).Path
$Store = Join-Path $GMod 'data\extreme_refresh'
$Snapshots = Join-Path $Store 'snapshots'
[System.IO.Directory]::CreateDirectory($Snapshots) | Out-Null
$utf8 = New-Object System.Text.UTF8Encoding($false)
$tracked = @{}
$dirty = @{}
$nextRev = 1
$webTypes = @('.html','.htm','.css','.js','.mjs','.json','.svg','.png','.jpg','.jpeg','.gif','.webp','.ico','.ttf','.otf','.woff','.woff2')
$maxLuaBytes = 4MB
$maxWebBytes = 8MB
$maxAssetBytes = 2MB
$maxAssets = 400

function Save-Atomic([string]$dest,[string]$content) {
    $temp = "$dest.tmp"
    [System.IO.File]::WriteAllText($temp, $content, $utf8)
    if ([System.IO.File]::Exists($dest)) {
        try { [System.IO.File]::Replace($temp, $dest, $null) }
        catch {
            [System.IO.File]::Delete($dest)
            [System.IO.File]::Move($temp, $dest)
        }
    } else { [System.IO.File]::Move($temp, $dest) }
}
function Publish-Manifest {
    $script:nextRev++
    $entries = @()
    foreach ($name in @($tracked.Keys | Sort-Object)) {
        $entries += @{ name = $name; version = [string]$tracked[$name]; snapshot = "extreme_refresh/snapshots/$name.txt" }
    }
    Save-Atomic (Join-Path $Store 'manifest.txt') (@{ revision = $nextRev; addons = @($entries) } | ConvertTo-Json -Compress -Depth 7)
}
function Snapshot-Addon([string]$name) {
    if ($name -eq 'extreme_lua_refresh' -or $name -notmatch '^[a-zA-Z0-9_-]+$') { return }
    $root = Join-Path $Addons $name
    $lua = Join-Path $root 'lua'
    if (-not [System.IO.Directory]::Exists($root)) {
        if ($tracked.ContainsKey($name)) {
            $tracked.Remove($name)
            Publish-Manifest
            Write-Host "[ELR] Unloaded $name" -ForegroundColor DarkYellow
        }
        return
    }
    if (-not [System.IO.Directory]::Exists($lua)) {
        if ($tracked.ContainsKey($name)) {
            $tracked.Remove($name)
            Publish-Manifest
            Write-Host "[ELR] Unloaded $name (Lua directory removed)" -ForegroundColor DarkYellow
        }
        return
    }
    $files = New-Object 'System.Collections.Generic.List[object]'
    $resources = New-Object 'System.Collections.Generic.List[object]'
    $bytes = 0L
    $resourceBytes = 0L
    try {
        foreach ($path in [System.IO.Directory]::EnumerateFiles($lua, '*.lua', [System.IO.SearchOption]::AllDirectories)) {
            $relative = $path.Substring($lua.Length).TrimStart([char]'\', [char]'/').Replace('\', '/')
            if ($relative -notmatch '^[a-zA-Z0-9_./-]+\.lua$' -or $relative.Contains('..')) { continue }
            $raw = [System.IO.File]::ReadAllText($path)
            $bytes += [System.Text.Encoding]::UTF8.GetByteCount($raw)
            if ($bytes -gt $maxLuaBytes) { throw 'Lua exceeds the current 4 MB snapshot limit' }
            $files.Add(@{path=$relative;code=$raw})
        }
        if ($files.Count -eq 0) {
            if ($tracked.ContainsKey($name)) {
                $tracked.Remove($name)
                Publish-Manifest
                Write-Host "[ELR] Unloaded $name (no Lua left)" -ForegroundColor DarkYellow
            }
            return
        }

        # Web resource discovery is extension-based, not tied to particular addons.
        # Exclude Lua / generated build dirs; everything else is eligible.
        foreach ($path in [System.IO.Directory]::EnumerateFiles($root, '*', [System.IO.SearchOption]::AllDirectories)) {
            $relative = $path.Substring($root.Length).TrimStart([char]'\', [char]'/').Replace('\', '/')
            if ($relative -notmatch '^[a-zA-Z0-9_./-]+$' -or $relative.Contains('..')) { continue }
            if ($relative -match '^(?i:lua|tools|node_modules|\.git|\.next|dist/node_modules)/') { continue }
            $ext = [System.IO.Path]::GetExtension($path).ToLowerInvariant()
            if ($webTypes -notcontains $ext) { continue }
            $size = ([System.IO.FileInfo]$path).Length
            if ($size -gt $maxAssetBytes -or $resourceBytes + $size -gt $maxWebBytes -or $resources.Count -ge $maxAssets) {
                Write-Warning "[ELR] Skipped asset (per-file/total limit): $name/$relative"
                continue
            }
            $rawBytes = [System.IO.File]::ReadAllBytes($path)
            $resourceBytes += $rawBytes.Length
            $resources.Add(@{path=$relative;base64=[Convert]::ToBase64String($rawBytes)})
        }
        $version = ([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds().ToString() + '-' + [Guid]::NewGuid().ToString('N').Substring(0,8))
        $snapshot = @{ name=$name;version=$version;files=@($files.ToArray());resources=@($resources.ToArray()) } | ConvertTo-Json -Compress -Depth 8
        Save-Atomic (Join-Path $Snapshots "$name.txt") $snapshot
        $tracked[$name] = $version
        Publish-Manifest
        Write-Host ("[ELR] {0}: {1} Lua files ({2} B), {3} web assets ({4} B)" -f $name,$files.Count,$bytes,$resources.Count,$resourceBytes) -ForegroundColor Green
    } catch {
        Write-Warning ("[ELR] {0}: {1}. Retry after next change" -f $name,$_.Exception.Message)
    }
}

# Leave already mounted addons alone to avoid executing them twice.
Publish-Manifest
$watcher = New-Object System.IO.FileSystemWatcher($Addons)
$watcher.IncludeSubdirectories = $true
$watcher.Filter = '*'
$watcher.NotifyFilter = [System.IO.NotifyFilters]'FileName, DirectoryName, LastWrite, CreationTime, Size'
$watcher.InternalBufferSize = 65536
$watcher.EnableRaisingEvents = $true
Write-Host '[ELR] General Lua + web asset monitor active' -ForegroundColor Cyan
Write-Host "[ELR] Addons: $Addons"
while ($true) {
    try {
        $change = $watcher.WaitForChanged([System.IO.WatcherChangeTypes]::All, 80)
        if (-not $change.TimedOut -and $change.Name) {
            $rel = $change.Name.Replace('/', '\')
            $name = $rel.Split([char]'\')[0]
            $candidate = Join-Path $Addons $rel
            $ext = [System.IO.Path]::GetExtension($rel).ToLowerInvariant()
            $isResource = ($ext -eq '.lua' -or $webTypes -contains $ext)
            $isDir = [System.IO.Directory]::Exists($candidate)
            $isRoot = -not $rel.Contains('\')
            $isGone = ($change.ChangeType -eq [System.IO.WatcherChangeTypes]::Deleted -or $change.ChangeType -eq [System.IO.WatcherChangeTypes]::Renamed)
            if ($name -match '^[a-zA-Z0-9_-]+$' -and $name -ne 'extreme_lua_refresh' -and ($isResource -or $isDir -or $isRoot -or $isGone)) {
                $dirty[$name] = [DateTime]::UtcNow
            }
        }
        $request = Join-Path $Store 'request.txt'
        if ([System.IO.File]::Exists($request)) {
            $wanted = [System.IO.File]::ReadAllText($request).Trim()
            [System.IO.File]::Delete($request)
            if ($wanted -match '^[a-zA-Z0-9_-]+$' -and $wanted -ne 'extreme_lua_refresh') { $dirty[$wanted] = [DateTime]::UtcNow.AddMilliseconds(-500) }
        }
        $now = [DateTime]::UtcNow
        foreach ($name in @($dirty.Keys)) {
            if (($now - $dirty[$name]).TotalMilliseconds -ge 240) {
                $dirty.Remove($name)
                Snapshot-Addon $name
            }
        }
    } catch {
        Write-Warning "[ELR] Watcher: $($_.Exception.Message)"
        Start-Sleep -Milliseconds 300
    }
}
