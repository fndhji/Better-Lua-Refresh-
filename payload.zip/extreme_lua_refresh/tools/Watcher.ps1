# Extreme Lua Refresh - localhost development watcher (Windows PowerShell 5.1+)
$ErrorActionPreference = 'Stop'
$AddonRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$Addons = (Resolve-Path (Join-Path $AddonRoot '..')).Path
$GMod = (Resolve-Path (Join-Path $Addons '..')).Path
$Store = Join-Path $GMod 'data\extreme_refresh'
$Snapshots = Join-Path $Store 'snapshots'
[System.IO.Directory]::CreateDirectory($Snapshots) | Out-Null
$utf8 = New-Object System.Text.UTF8Encoding($false)
$tracked = @{}
$dirty = @{}
$nextRev = 1

function Save-Atomic([string]$dest,[string]$content) {
    $temp = "$dest.tmp"
    [System.IO.File]::WriteAllText($temp, $content, $utf8)
    if ([System.IO.File]::Exists($dest)) {
        try { [System.IO.File]::Replace($temp, $dest, $null) }
        catch {
            [System.IO.File]::Delete($dest)
            [System.IO.File]::Move($temp, $dest)
        }
    } else { [System.IO.File]::Move($temp, $dest) }
}
function Publish-Manifest {
    $script:nextRev++
    $entries = @()
    foreach ($name in @($tracked.Keys | Sort-Object)) {
        $entries += @{ name = $name; version = [string]$tracked[$name]; snapshot = "extreme_refresh/snapshots/$name.txt" }
    }
    $payload = @{ revision = $nextRev; addons = @($entries) } | ConvertTo-Json -Compress -Depth 7
    Save-Atomic (Join-Path $Store 'manifest.txt') $payload
}
function Snapshot-Addon([string]$name) {
    if ($name -eq 'extreme_lua_refresh' -or $name -notmatch '^[a-zA-Z0-9_-]+$') { return }
    $root = Join-Path $Addons $name
    $lua = Join-Path $root 'lua'
    if (-not [System.IO.Directory]::Exists($root)) {
        if ($tracked.ContainsKey($name)) {
            $tracked.Remove($name)
            Publish-Manifest
            Write-Host "[ELR] Decharge : $name" -ForegroundColor DarkYellow
        }
        return
    }
    if (-not [System.IO.Directory]::Exists($lua)) { return }
    $files = @()
    $bytes = 0
    try {
        foreach ($path in [System.IO.Directory]::EnumerateFiles($lua, '*.lua', [System.IO.SearchOption]::AllDirectories)) {
            $relative = $path.Substring($lua.Length).TrimStart([char]'\', [char]'/').Replace('\', '/')
            if ($relative -notmatch '^[a-zA-Z0-9_./-]+\.lua$' -or $relative.Contains('..')) { continue }
            $raw = [System.IO.File]::ReadAllText($path)
            $bytes += [System.Text.Encoding]::UTF8.GetByteCount($raw)
            if ($bytes -gt 4MB) { throw 'Addon Lua > 4 Mo, trop gros pour le mode refresh rapide' }
            $files += @{ path = $relative; code = $raw }
        }
        if ($files.Count -eq 0) { return }
        $version = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds().ToString()
        $snapshot = @{ name = $name; version = $version; files = @($files) } | ConvertTo-Json -Compress -Depth 8
        Save-Atomic (Join-Path $Snapshots "$name.txt") $snapshot
        $tracked[$name] = $version
        Publish-Manifest
        Write-Host ("[ELR] {0}: {1} fichiers Lua, {2:n0} octets" -f $name,$files.Count,$bytes) -ForegroundColor Green
    } catch {
        Write-Warning ("[ELR] {0}: {1}. Essai au prochain changement." -f $name, $_.Exception.Message)
    }
}

# Start with no managed addons: GMod already initialized its installed addons.
Publish-Manifest
$watcher = New-Object System.IO.FileSystemWatcher($Addons)
$watcher.IncludeSubdirectories = $true
$watcher.Filter = '*'
$watcher.NotifyFilter = [System.IO.NotifyFilters]'FileName, DirectoryName, LastWrite, CreationTime, Size'
$watcher.InternalBufferSize = 65536
$watcher.EnableRaisingEvents = $true
Write-Host '[ELR] Extreme Lua Refresh actif.' -ForegroundColor Cyan
Write-Host "[ELR] Surveillance : $Addons"
Write-Host '[ELR] Ajoute un addon ou sauvegarde un .lua ; CTRL+C pour arreter.'

while ($true) {
    try {
        $change = $watcher.WaitForChanged([System.IO.WatcherChangeTypes]::All, 80)
        if (-not $change.TimedOut -and $change.Name) {
            $rel = $change.Name.Replace('/', '\')
            $name = $rel.Split([char]'\')[0]
            $candidate = Join-Path $Addons $rel
            $isLua = $rel.EndsWith('.lua', [StringComparison]::OrdinalIgnoreCase)
            $isDirectory = [System.IO.Directory]::Exists($candidate)
            $isAddonRoot = -not $rel.Contains('\')
            if ($name -match '^[a-zA-Z0-9_-]+$' -and $name -ne 'extreme_lua_refresh' -and ($isLua -or $isDirectory -or $isAddonRoot)) {
                $dirty[$name] = [DateTime]::UtcNow
            }
        }
        $request = Join-Path $Store 'request.txt'
        if ([System.IO.File]::Exists($request)) {
            $wanted = [System.IO.File]::ReadAllText($request).Trim()
            [System.IO.File]::Delete($request)
            if ($wanted -match '^[a-zA-Z0-9_-]+$') { $dirty[$wanted] = [DateTime]::UtcNow.AddMilliseconds(-500) }
        }
        $now = [DateTime]::UtcNow
        foreach ($name in @($dirty.Keys)) {
            if (($now - $dirty[$name]).TotalMilliseconds -ge 240) {
                $dirty.Remove($name)
                Snapshot-Addon $name
            }
        }
    } catch {
        Write-Warning "[ELR] Watcher: $($_.Exception.Message)"
        Start-Sleep -Milliseconds 300
    }
}
