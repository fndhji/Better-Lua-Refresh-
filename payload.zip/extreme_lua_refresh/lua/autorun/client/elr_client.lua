include('elr/runtime.lua')

local pending = {}

net.Receive('elr_chunk_v1', function()
    local name = net.ReadString()
    local version = net.ReadString()
    local index = net.ReadUInt(16)
    local total = net.ReadUInt(16)
    local len = net.ReadUInt(16)
    if not name:match('^[%w_-]+$') or total == 0 or total > 8000 or
        index < 1 or index > total or len > 22000 then return end
    local bytes = net.ReadData(len)
    if type(bytes) ~= 'string' then return end
    local key = name .. ':' .. version
    local state = pending[key]
    if not state then
        state = { blocks = {}, received = 0, total = total, bytes = 0 }
        pending[key] = state
    end
    if state.total ~= total then pending[key] = nil return end
    if not state.blocks[index] then
        state.blocks[index] = bytes
        state.received = state.received + 1
        state.bytes = state.bytes + #bytes
    end
    if state.bytes > 16 * 1024 * 1024 then pending[key] = nil return end
    if state.received == total then
        local packed = table.concat(state.blocks)
        pending[key] = nil
        local raw = util.Decompress(packed)
        local snap = raw and util.JSONToTable(raw) or nil
        if snap and snap.name == name and tostring(snap.version) == version then
            ExtremeRefreshRuntime.Apply(snap)
        end
    end
end)

net.Receive('elr_remove_v1', function()
    local name = net.ReadString()
    ExtremeRefreshRuntime.Remove(name)
end)

concommand.Add('elr_client_status', function()
    print('[ELR] Addons client charges : ' .. table.Count(ExtremeRefreshRuntime.loaded))
end)

concommand.Add('elr_status', function()
    net.Start('elr_cmd_v1')
    net.WriteString('status')
    net.SendToServer()
end)

concommand.Add('elr_force', function(_, _, args)
    local name = args[1]
    if type(name) ~= 'string' or not name:match('^[%w_-]+$') then
        print('[ELR] Utilisation : elr_force nom_du_dossier_addon')
        return
    end
    net.Start('elr_cmd_v1')
    net.WriteString('force')
    net.WriteString(name)
    net.SendToServer()
end)
