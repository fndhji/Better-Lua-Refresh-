AddCSLuaFile('elr/runtime.lua')
AddCSLuaFile('autorun/client/elr_client.lua')
include('elr/runtime.lua')

util.AddNetworkString('elr_chunk_v1')
util.AddNetworkString('elr_remove_v1')
util.AddNetworkString('elr_cmd_v1')

local known = {}
local lastManifest = ''
local jobs = {}
local CHUNK = 22000 -- below the GMod net limit, with headroom.

local function queueSnapshot(snapshot, to)
    local raw = util.TableToJSON(snapshot)
    if not raw then return end
    local compressed = util.Compress(raw)
    if not compressed then return end
    local total = math.ceil(#compressed / CHUNK)
    if total > 65535 then
        ErrorNoHalt('[ELR] Addon trop gros pour transfert : ' .. snapshot.name .. '\n')
        return
    end
    jobs[#jobs + 1] = {
        name = snapshot.name,
        version = tostring(snapshot.version),
        contents = compressed,
        count = total,
        index = 1,
        to = to
    }
end

timer.Create('ELR_SendPackets', 0.055, 0, function()
    local job = jobs[1]
    if not job then return end
    if IsValid(job.to) == false and job.to ~= nil then
        table.remove(jobs, 1)
        return
    end
    local offset = (job.index - 1) * CHUNK + 1
    local block = job.contents:sub(offset, offset + CHUNK - 1)
    net.Start('elr_chunk_v1')
    net.WriteString(job.name)
    net.WriteString(job.version)
    net.WriteUInt(job.index, 16)
    net.WriteUInt(job.count, 16)
    net.WriteUInt(#block, 16)
    net.WriteData(block, #block)
    if job.to then net.Send(job.to) else net.Broadcast() end
    job.index = job.index + 1
    if job.index > job.count then table.remove(jobs, 1) end
end)

local function removeAddon(name)
    ExtremeRefreshRuntime.Remove(name)
    known[name] = nil
    net.Start('elr_remove_v1')
    net.WriteString(name)
    net.Broadcast()
end

local function poll()
    local raw = file.Read('extreme_refresh/manifest.txt', 'DATA')
    if not raw or raw == lastManifest then return end
    local manifest = util.JSONToTable(raw)
    if type(manifest) ~= 'table' or type(manifest.addons) ~= 'table' then return end
    lastManifest = raw
    local active = {}
    for _, entry in ipairs(manifest.addons) do
        local name = entry.name
        if type(name) == 'string' and name:match('^[%w_-]+$')
            and type(entry.snapshot) == 'string'
            and entry.snapshot == 'extreme_refresh/snapshots/' .. name .. '.txt' then
            active[name] = true
            if not known[name] or tostring(known[name].version) ~= tostring(entry.version) then
                local contents = file.Read(entry.snapshot, 'DATA')
                local snap = contents and util.JSONToTable(contents) or nil
                if snap and snap.name == name and tostring(snap.version) == tostring(entry.version) then
                    local ok = ExtremeRefreshRuntime.Apply(snap)
                    -- Avoid repeating syntax errors 10 times per second.
                    local current = ExtremeRefreshRuntime.loaded[name]
                    known[name] = { version = entry.version, snapshot = current and current.snapshot or nil }
                    if ok then
                        queueSnapshot(snap)
                    elseif not current then
                        net.Start('elr_remove_v1')
                        net.WriteString(name)
                        net.Broadcast()
                    end
                end
            end
        end
    end
    for name in pairs(table.Copy(known)) do
        if not active[name] then removeAddon(name) end
    end
end

timer.Create('ELR_CheckManifest', 0.10, 0, poll)

hook.Add('PlayerInitialSpawn', 'ELR_OnNewPlayer', function(ply)
    timer.Simple(3, function()
        if not IsValid(ply) then return end
        for _, entry in pairs(known) do
            if entry.snapshot then queueSnapshot(entry.snapshot, ply) end
        end
    end)
end)

concommand.Add('elr_status', function(ply)
    if IsValid(ply) and not (ply:IsSuperAdmin() or ply:IsListenServerHost()) then return end
    print('[ELR] Addons sous surveillance : ' .. table.Count(known))
    for name, entry in pairs(known) do
        print('  ' .. name .. '  (' .. (entry.snapshot and 'charge' or 'erreur') .. ')')
    end
end)

concommand.Add('elr_force', function(ply, _, args)
    if IsValid(ply) and not (ply:IsSuperAdmin() or ply:IsListenServerHost()) then return end
    local name = args[1]
    if type(name) ~= 'string' or not name:match('^[%w_-]+$') then
        print('[ELR] Utilisation : elr_force nom_du_dossier_addon')
        return
    end
    file.Write('extreme_refresh/request.txt', name)
    print('[ELR] Refresh demande : ' .. name)
end)

-- Host can use these commands in their client console, even in localhost.
net.Receive('elr_cmd_v1', function(_, ply)
    if not IsValid(ply) or not (ply:IsListenServerHost() or ply:IsSuperAdmin()) then return end
    local operation = net.ReadString()
    if operation == 'status' then
        ply:PrintMessage(HUD_PRINTCONSOLE, '[ELR] Addons surveilles : ' .. table.Count(known) .. '\n')
        for name, entry in pairs(known) do
            ply:PrintMessage(HUD_PRINTCONSOLE, ' - ' .. name .. ' : ' .. (entry.snapshot and 'OK' or 'ERREUR') .. '\n')
        end
    elseif operation == 'force' then
        local name = net.ReadString()
        if not name:match('^[%w_-]+$') then return end
        file.Write('extreme_refresh/request.txt', name)
        ply:PrintMessage(HUD_PRINTCONSOLE, '[ELR] Demande envoyee : ' .. name .. '\n')
    end
end)
