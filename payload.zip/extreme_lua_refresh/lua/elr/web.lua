-- ELR web-asset bridge. Used by every addon loaded through an ELR snapshot.
-- Source does not mount a newly copied addon until map/game startup.
-- For local DHTML documents, build a self-contained document from the snapshot.
if not CLIENT then return end
local R = ExtremeRefreshRuntime
local mime = {
    png='image/png', jpg='image/jpeg', jpeg='image/jpeg', gif='image/gif',
    webp='image/webp', ico='image/x-icon', svg='image/svg+xml',
    ttf='font/ttf', otf='font/otf', woff='font/woff', woff2='font/woff2',
    css='text/css', js='application/javascript', mjs='application/javascript',
    json='application/json'
}

local function safePath(path)
    if type(path) ~= 'string' or path == '' then return nil end
    path = path:gsub('\\','/'):gsub('[?#].*$', '')
    if path:sub(1,1) == '/' or path:match('^%a[%w+.-]*:') then return nil end
    local out = {}
    for piece in path:gmatch('[^/]+') do
        if piece == '..' then
            if #out == 0 then return nil end
            out[#out] = nil
        elseif piece ~= '.' and piece ~= '' then
            if not piece:match('^[%w_.-]+$') then return nil end
            out[#out+1] = piece
        end
    end
    return table.concat(out, '/')
end

local function resolve(scope, from, reference)
    if type(reference) ~= 'string' then return nil end
    reference = reference:gsub('^%s+',''):gsub('%s+$','')
    if reference:sub(1, 18) == 'asset://garrysmod/' then
        local path = reference:sub(19)
        local prefix = 'addons/' .. scope.name .. '/'
        if path:sub(1,#prefix) == prefix then path = path:sub(#prefix + 1) end
        return safePath(path)
    end
    if reference:match('^[/\\]') or reference:match('^%a[%w+.-]*:') or reference:match('^//') then
        return nil
    end
    local dir = from:match('^(.*)/[^/]+$') or ''
    return safePath((dir == '' and '' or (dir .. '/')) .. reference)
end

local function bytes(scope, path)
    local record = scope.resources and scope.resources[path]
    if not record then return nil end
    if not record.decoded then
        record.decoded = util.Base64Decode(record.base64)
    end
    return record.decoded
end

local function dataURL(scope,path)
    local ext = path:match('%.([%w]+)$')
    local typ = ext and mime[ext:lower()]
    local asset = scope.resources and scope.resources[path]
    if not typ or not asset then return nil end
    return 'data:' .. typ .. ';base64,' .. asset.base64
end

local function attr(tag, name)
    local double = tag:match(name .. '%s*=%s*"([^"]+)"')
    if double then return double end
    local single = tag:match(name .. "%s*=%s*'([^']+)'")
    if single then return single end
    return tag:match(name .. '%s*=%s*([^%s>]+)')
end

local function replaceAttr(tag, key, from, to)
    -- Match the complete quoted value; never treat filenames as Lua patterns.
    local pattern = '(' .. key .. '%s*=%s*)([\"\'])' .. '(.-)%2'
    local output = tag:gsub(pattern, function(prefix,quote,value)
        if value ~= from then return prefix .. quote .. value .. quote end
        return prefix .. quote .. to .. quote
    end, 1)
    return output
end

local function rewriteCSS(scope, css, from)
    return css:gsub('url%s*%(([^%)]+)%)', function(inner)
        local ref = inner:gsub('^%s+',''):gsub('%s+$',''):gsub("^[\"']",''):gsub("[\"']$",'')
        local path = resolve(scope,from,ref)
        local url = path and dataURL(scope,path)
        if url and #url <= 24000 then return 'url("' .. url .. '")' end
            -- Keep the first HTML document tiny. Big fonts and backgrounds are
            -- hydrated after CEF has built the DOM, through the panel callback.
            if url then return 'url("elr-virtual://' .. path .. '")' end
            return 'url(' .. inner .. ')'
    end)
end

-- Runtime asset resolution for resources created by JavaScript after page load.
-- Works on the entire snapshot, not on any addon-specific URL or UI identifier.
local bridgeJS = [==[
(function () {
  'use strict';
  var files = __ELR_FILES__;
  var known = __ELR_KNOWN__;
  var inflight = {};
  var buffers = {};
  var waiters = {};
  var addon = __ELR_ADDON__;
  var pageDir = __ELR_BASE__;
  var addonPrefix = 'asset://garrysmod/addons/' + addon + '/';
  function requestAsset(key, node) {
    if (!Object.prototype.hasOwnProperty.call(known, key)) return;
    if (node) {
      if (!waiters[key]) waiters[key] = [];
      if (waiters[key].indexOf(node) === -1) waiters[key].push(node);
    }
    if (inflight[key]) return;
    inflight[key] = true;
    try {
      if (window.elrWeb && typeof window.elrWeb.fetch === 'function')
        window.elrWeb.fetch(key);
      else inflight[key] = false;
    } catch (_) { inflight[key] = false; }
  }
  function resolve(input, node) {
    if (typeof input !== 'string' || !input) return input;
    var raw = input.trim();
    var path;
    if (raw.indexOf('elr-virtual://') === 0) {
      path = raw.slice('elr-virtual://'.length);
    } else if (raw.indexOf(addonPrefix) === 0) {
      path = raw.slice(addonPrefix.length);
    } else if (/^(?:[a-z][a-z0-9+.-]*:|\/\/|\/|#)/i.test(raw)) {
      return input; // Never touch HTTP, blob, data, other addons, or anchors.
    } else {
      path = pageDir + raw;
    }
    path = path.replace(/[?#].*$/, '').replace(/\\/g, '/');
    var out = [];
    var bits = path.split('/');
    for (var i = 0; i < bits.length; i++) {
      if (!bits[i] || bits[i] === '.') continue;
      if (bits[i] === '..') {
        if (!out.length) return input;
        out.pop();
      } else {
        out.push(bits[i]);
      }
    }
    var key = out.join('/');
    if (Object.prototype.hasOwnProperty.call(files, key)) return files[key];
    requestAsset(key, node);
    return input;
  }
  function rewriteStyle(value, node) {
    if (typeof value !== 'string' || value.indexOf('url(') < 0) return value;
    return value.replace(/url\(\s*(['"]?)([^'"\)]+)\1\s*\)/gi, function (all, quote, path) {
      var url = resolve(path, node);
      return url === path ? all : 'url("' + url + '")';
    });
  }
  // Covers img.src=..., new Image().src=..., script.src=..., etc.
  function patchProperty(type, name, mapper) {
    if (typeof type === 'undefined' || !type.prototype) return;
    var descriptor = Object.getOwnPropertyDescriptor(type.prototype, name);
    if (!descriptor || !descriptor.configurable || typeof descriptor.set !== 'function') return;
    try {
      Object.defineProperty(type.prototype, name, {
        configurable: true,
        enumerable: descriptor.enumerable,
        get: descriptor.get,
        set: function (value) { return descriptor.set.call(this, mapper(value, this)); }
      });
    } catch (_) { /* Browser implementation may have a non-overridable setter. */ }
  }
  patchProperty(window.HTMLImageElement, 'src', resolve);
  patchProperty(window.HTMLScriptElement, 'src', resolve);
  patchProperty(window.HTMLMediaElement, 'src', resolve);
  patchProperty(window.HTMLSourceElement, 'src', resolve);
  patchProperty(window.HTMLLinkElement, 'href', resolve);
  patchProperty(window.HTMLVideoElement, 'poster', resolve);
  patchProperty(window.CSSStyleDeclaration, 'backgroundImage', rewriteStyle);
  patchProperty(window.CSSStyleDeclaration, 'background', rewriteStyle);
  patchProperty(window.CSSStyleDeclaration, 'maskImage', rewriteStyle);
  var nativeSetAttribute = Element.prototype.setAttribute;
  Element.prototype.setAttribute = function (key, value) {
    var name = String(key).toLowerCase();
    if (name === 'src' || name === 'poster' || (name === 'href' && /^(LINK|IMAGE|USE)$/i.test(this.tagName))) {
      value = resolve(value, this);
    } else if (name === 'style') {
      value = rewriteStyle(value, this);
    }
    return nativeSetAttribute.call(this, key, value);
  };
  if (window.CSSStyleDeclaration && CSSStyleDeclaration.prototype.setProperty) {
    var originalSetProperty = CSSStyleDeclaration.prototype.setProperty;
    CSSStyleDeclaration.prototype.setProperty = function (name, value, priority) {
      return originalSetProperty.call(this, name, rewriteStyle(value, this), priority);
    };
  }
  // Fallback for frameworks that generate complete DOM trees/innerHTML after load.
  // It also covers engines that do not permit property-setter interception.
  function fixElement(element) {
    if (!element || element.nodeType !== 1) return;
    var tag = element.tagName;
    if (tag === 'STYLE') {
      var css = element.textContent || '';
      if (css.indexOf('elr-virtual://') !== -1) {
        var replaced = css.replace(/elr-virtual:\/\/([\w./-]+)/g, function (match, key) {
          if (Object.prototype.hasOwnProperty.call(files, key)) return files[key];
          requestAsset(key, element);
          return match;
        });
        if (replaced !== css) element.textContent = replaced;
      }
    }
    var fields = ['src', 'poster'];
    if (tag === 'LINK' || tag === 'IMAGE' || tag === 'USE') fields.push('href');
    for (var k = 0; k < fields.length; k++) {
      var name = fields[k];
      var before = element.getAttribute(name);
      if (before !== null) {
        var after = resolve(before, element);
        if (after !== before) nativeSetAttribute.call(element, name, after);
      }
    }
    var style = element.getAttribute('style');
    if (style !== null) {
      var rewritten = rewriteStyle(style, element);
      if (rewritten !== style) nativeSetAttribute.call(element, 'style', rewritten);
    }
  }
  function scan(element) {
    fixElement(element);
    if (element.querySelectorAll) {
      var descendants = element.querySelectorAll('[src],[poster],[href],[style]');
      for (var k = 0; k < descendants.length; k++) fixElement(descendants[k]);
    }
  }
  if (window.MutationObserver) {
    var observer = new MutationObserver(function (records) {
      for (var i = 0; i < records.length; i++) {
        if (records[i].type === 'attributes') fixElement(records[i].target);
        else {
          var nodes = records[i].addedNodes;
          for (var n = 0; n < nodes.length; n++) scan(nodes[n]);
        }
      }
    });
    observer.observe(document, {
      attributes: true, attributeFilter: ['src', 'href', 'poster', 'style'],
      childList: true, subtree: true
    });
  }
  function receive(key, chunk, last) {
    if (!Object.prototype.hasOwnProperty.call(known, key)) return;
    buffers[key] = (buffers[key] || '') + chunk;
    if (!last) return;
    var ext = key.split('.').pop().toLowerCase();
    var types = {png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',gif:'image/gif',webp:'image/webp',ico:'image/x-icon',svg:'image/svg+xml',ttf:'font/ttf',otf:'font/otf',woff:'font/woff',woff2:'font/woff2',css:'text/css',js:'application/javascript',mjs:'application/javascript',json:'application/json'};
    if (!types[ext]) return;
    files[key] = 'data:' + types[ext] + ';base64,' + buffers[key];
    delete buffers[key];
    delete inflight[key];
    var nodes = waiters[key] || [];
    delete waiters[key];
    for (var i = 0; i < nodes.length; i++) fixElement(nodes[i]);
  }
  window.ELRWebAssets = Object.freeze({ resolve: resolve, receive: receive });
})();
]==]

local function dynamicBridge(scope, pagePath)
    local dir = pagePath:match('^(.*)/[^/]+$') or ''
    if dir ~= '' then dir = dir .. '/' end
    -- Embed the snapshot's browser resources as a scoped in-page asset table.
    -- Paths have already been validated by the watcher/runtime. %q escapes JS strings.
    local entries = {}
    local names = {}
    -- Large resources are hydrated on demand, so the initial HTML stays small.
    -- Do not put fonts into the JS table: CSS references are delivered through
    -- elr-virtual:// URLs and a small, asynchronous bridge.
    -- Bound the in-document asset map; larger resources are fetched on demand.
    for path in pairs(scope.resources or {}) do
        local ext = (path:match('%.([%w]+)$') or ''):lower()
        local record = scope.resources[path]
        if ext ~= 'ttf' and ext ~= 'otf' and ext ~= 'woff' and ext ~= 'woff2'
            and mime[ext] and record and #record.base64 <= 100000 then
            names[#names+1] = path
        end
    end
    table.sort(names)
    local embedded = 0
    local allNames = {}
    for path in pairs(scope.resources or {}) do
        if dataURL(scope,path) then allNames[#allNames+1] = path end
    end
    table.sort(allNames)
    for _, path in ipairs(names) do
        local url = dataURL(scope,path)
        -- Keep the initial page small even if an addon has hundreds of images.
        if embedded + #url <= 180000 then
            entries[#entries+1] = string.format('%q:%q', path, url)
            embedded = embedded + #url
        end
    end
    local script = bridgeJS
    local known = {}
    for _, path in ipairs(allNames) do known[#known+1] = string.format('%q:true',path) end
    script = script:gsub('__ELR_FILES__', function() return '{' .. table.concat(entries, ',') .. '}' end)
    script = script:gsub('__ELR_KNOWN__', function() return '{' .. table.concat(known, ',') .. '}' end)
    script = script:gsub('__ELR_ADDON__', function() return string.format('%q',scope.name) end)
    script = script:gsub('__ELR_BASE__', function() return string.format('%q',dir) end)
    return '<script>' .. script .. '</script>'
end

local function compose(scope, path)
    scope.htmlCache = scope.htmlCache or {}
    if scope.htmlCache[path] then return scope.htmlCache[path] end
    local html = bytes(scope,path)
    if not html then return nil, 'HTML resource not included in snapshot: ' .. path end
    local errors = {}
    local function scriptTag(attrs,inside)
        local src = attr(attrs,'src')
        if not src then return '<script' .. attrs .. '>' .. inside .. '</script>' end
        local dep = resolve(scope,path,src)
        local js = dep and bytes(scope,dep)
        if not js then
            errors[#errors+1] = 'script: ' .. src
            return ''
        end
        -- Data URL avoids embedding a literal closing script tag from a JS string.
        local uri = dataURL(scope,dep)
        if not uri then errors[#errors+1] = 'script type: ' .. src return '' end
        -- Preserve defer / module attributes by editing only the src value.
        return '<script' .. replaceAttr(attrs,'src',src,uri) .. '></script>'
    end
    html = html:gsub('<script([^>]*)>(.-)</script>',scriptTag)
    html = html:gsub('<link([^>]*)>',function(attrs)
        local rel = attr(attrs, 'rel')
        local href = attr(attrs,'href')
        if not href then return '<link' .. attrs .. '>' end
        local dep = resolve(scope,path,href)
        if rel and rel:lower():find('stylesheet',1,true) then
            local css = dep and bytes(scope,dep)
            if not css then errors[#errors+1]='css: ' .. href return '' end
            return '<style>' .. rewriteCSS(scope,css,dep) .. '</style>'
        end
        local url = dep and dataURL(scope,dep)
        if url then
            return '<link' .. replaceAttr(attrs,'href',href,url) .. '>'
        end
        return '<link' .. attrs .. '>'
    end)
    -- Relative media links in document markup. CSS images and fonts use rewriteCSS.
    html = html:gsub('<([%a][^>]*)>',function(tag)
        local prefix = tag:match('^%s*([%a]+)') or ''
        prefix = prefix:lower()
        if prefix == 'script' or prefix == 'style' then return '<'..tag..'>' end
        local result = tag
        for _, key in ipairs({'src','poster'}) do
            local reference = attr(result,key)
            if reference then
                local dep = resolve(scope,path,reference)
                local url = dep and dataURL(scope,dep)
                if url then
                    result = replaceAttr(result,key,reference,#url <= 24000 and url or ('elr-virtual://'..dep))
                end
            end
        end
        return '<' .. result .. '>'
    end)
    if #errors > 0 then
        return nil, 'Missing web resources: ' .. table.concat(errors, ', ')
    end
    -- Inject before page scripts execute, so JS-created images and DOM nodes
    -- can use the same virtual resources as static HTML and CSS.
    local bridge = dynamicBridge(scope, path)
    local injected = false
    html = html:gsub('(<[Hh][Ee][Aa][Dd][^>]*>)', function(openTag)
        if injected then return openTag end
        injected = true
        return openTag .. bridge
    end, 1)
    if not injected then html = bridge .. html end
    scope.htmlCache[path] = html
    return html
end

-- Public optional API for addons that explicitly want to load a virtual page.
function R.BuildHTML(name,path)
    local scope = R.loaded[name]
    if not scope then return nil,'Addon is not managed by ELR: ' .. tostring(name) end
    local normalized = safePath(path)
    if not normalized then return nil,'Invalid HTML path' end
    return compose(scope,normalized)
end

-- Automatic compatibility: apply to any DHTML panel created by an ELR addon.
-- The original browser remains unchanged for HTTP URLs and mounted external assets.
function R.WrapDHTML(scope,panel)
    if not IsValid(panel) or panel.ELRWebWrapped then return panel end
    local nativeOpen = panel.OpenURL
    if type(nativeOpen) ~= 'function' then return panel end
    panel.ELRWebWrapped = true
    -- Browser requests large assets only when needed. Transfer in small chunks
    -- to avoid sending multi-megabyte SetHTML/Call messages into GMod's CEF.
    panel.ELRWebAssetRequests = {}
    if type(panel.AddFunction) == 'function' then
    panel:AddFunction('elrWeb','fetch',function(path)
        if not IsValid(panel) or type(path) ~= 'string' then return end
        local record = scope.resources and scope.resources[path]
        if not record or type(record.base64) ~= 'string'
            or #record.base64 > 2800000 or panel.ELRWebAssetRequests[path] then return end
        local ext = (path:match('%.([%w]+)$') or ''):lower()
        if not mime[ext] then return end
        panel.ELRWebAssetRequests[path] = true
        local pos = 1
        local function pump()
            if not IsValid(panel) then return end
            local sent = 0
            while pos <= #record.base64 and sent < 6 do
                local chunk = record.base64:sub(pos,pos+12287)
                pos = pos + #chunk
                sent = sent + 1
                panel:Call(('window.ELRWebAssets.receive(%q,%q,%s);'):format(path,chunk,tostring(pos > #record.base64)))
            end
            if pos <= #record.base64 then timer.Simple(0.04,pump) end
        end
        pump()
    end)
    end
    panel.OpenURL = function(self, url, ...)
        if type(url) == 'string' then
            local path = resolve(scope,'',url)
            if path and path:lower():match('%.html?$') then
                local available = scope.resources and scope.resources[path]
                local belongsToAddon = url:find('asset://garrysmod/addons/' .. scope.name .. '/',1,true) == 1
                    or path:find('materials/' .. scope.name .. '/',1,true) == 1
                if available then
                    local doc, err = compose(scope,path)
                    if doc then
                        print(('[ELR WEB] Local DHTML: %s/%s (document %d KB)'):format(scope.name,path, math.floor(#doc/1024)))
                        return self:SetHTML(doc)
                    end
                    ErrorNoHalt('[ELR WEB] ' .. scope.name .. '/' .. path .. ': ' .. tostring(err) .. '\n')
                    return self:SetHTML('<body style="background:#191919;color:#ddd;font:14px Arial;padding:20px">ELR web resource error. Check the Garry\'s Mod console.</body>')
                elseif belongsToAddon and not file.Exists(path,'GAME') then
                    ErrorNoHalt('[ELR WEB] Missing HTML snapshot asset: ' .. scope.name .. '/' .. path .. '\n')
                    return self:SetHTML('<body style="background:#191919;color:#ddd;font:14px Arial;padding:20px">ELR HTML file missing from snapshot. Check console.</body>')
                end
            end
        end
        return nativeOpen(self,url,...)
    end
    return panel
end
