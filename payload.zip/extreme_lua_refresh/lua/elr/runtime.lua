-- Extreme Lua Refresh - runtime for Lua-only development addons.
-- Source code comes from the local Windows watcher / trusted server only.
ExtremeRefreshRuntime = ExtremeRefreshRuntime or {}
local R = ExtremeRefreshRuntime
R.loaded = R.loaded or {}

local function norm(path)
    if type(path) ~= 'string' then return nil end
    path = path:gsub('\\', '/'):gsub('^lua/', ''):gsub('^%./', '')
    if path:find('%.%./', 1, false) or path:sub(1, 1) == '/' then return nil end
    return path
end

local function cleanup(scope)
    if not scope then return end
    for _, v in ipairs(scope.hooks or {}) do hook.Remove(v[1], v[2]) end
    for _, name in ipairs(scope.timers or {}) do timer.Remove(name) end
    for _, name in ipairs(scope.commands or {}) do concommand.Remove(name) end
    for _, name in ipairs(scope.receivers or {}) do net.Receive(name, function() end) end
    for _, pnl in ipairs(scope.panels or {}) do if IsValid(pnl) then pnl:Remove() end end
    -- Global variables, external callbacks, C++ objects and entity instances
    -- cannot be rolled back generically.
end

function R.Remove(name)
    if type(name) ~= 'string' then return end
    local old = R.loaded[name]
    if not old then return end
    cleanup(old)
    R.loaded[name] = nil
    print('[ELR] Decharge Lua ' .. name)
end

local function makeEnvironment(scope, compiled, sources)
    local env = {}
    setmetatable(env, { __index = _G, __newindex = _G })
    local currentPath
    local compiling = {}

    local function run(path)
        local fn = compiled[path]
        if not fn then return nil end
        if compiling[path] then error('include circulaire : ' .. path) end
        compiling[path] = true
        local previous = currentPath
        currentPath = path
        setfenv(fn, env)
        local result = { xpcall(fn, debug.traceback) }
        currentPath = previous
        compiling[path] = nil
        if not result[1] then error(result[2]) end
        return unpack(result, 2)
    end

    rawset(env, "include", function(path)
        local clean = norm(path)
        if not clean then error('Chemin include invalide') end
        if compiled[clean] then return run(clean) end
        if currentPath then
            local dir = currentPath:match('^(.*)/[^/]+$')
            local relative = dir and norm(dir .. '/' .. clean)
            if relative and compiled[relative] then return run(relative) end
        end
        return include(path) -- Other mounted addons and core GMod.
    end)
    rawset(env, "AddCSLuaFile", function() end) -- Client bundle is handled by the watcher bridge.

    -- Lua virtual filesystem for newly dropped, unmounted addons.
    -- This is particularly important for frameworks using recursive file.Find.
    local function sourcePath(path)
        if type(path) ~= 'string' then return nil end
        path = path:gsub('\\', '/')
        return norm(path)
    end
    local function virtualFind(pattern, pathId)
        if pathId ~= 'LUA' and pathId ~= 'lsv' and pathId ~= 'lcl' and pathId ~= 'GAME' then
            return file.Find(pattern, pathId)
        end
        local normalized = sourcePath(pattern)
        if not normalized then return file.Find(pattern, pathId) end
        local dir, mask = normalized:match('^(.*)/([^/]*)$')
        if not dir then dir, mask = '', normalized end
        local maskPattern = '^' .. mask:gsub('([%%%^%$%(%)%.%[%]%+%-%]])', '%%%1')
            :gsub('%*', '.*'):gsub('%?', '.') .. '$'
        local foundFiles, foundDirs = {}, {}
        local alreadyFiles, alreadyDirs = {}, {}
        local originalFiles, originalDirs = file.Find(pattern, pathId)
        for _, v in ipairs(originalFiles or {}) do
            if not alreadyFiles[v] then foundFiles[#foundFiles + 1] = v; alreadyFiles[v] = true end
        end
        for _, v in ipairs(originalDirs or {}) do
            if not alreadyDirs[v] then foundDirs[#foundDirs + 1] = v; alreadyDirs[v] = true end
        end
        local prefix = dir == '' and '' or (dir .. '/')
        for path in pairs(sources) do
            if path:sub(1, #prefix) == prefix then
                local rest = path:sub(#prefix + 1)
                if rest ~= '' then
                    local folder = rest:match('^([^/]+)/')
                    if folder then
                        if folder:match(maskPattern) and not alreadyDirs[folder] then
                            foundDirs[#foundDirs + 1] = folder
                            alreadyDirs[folder] = true
                        end
                    elseif rest:match(maskPattern) and not alreadyFiles[rest] then
                        foundFiles[#foundFiles + 1] = rest
                        alreadyFiles[rest] = true
                    end
                end
            end
        end
        table.sort(foundFiles)
        table.sort(foundDirs)
        return foundFiles, foundDirs
    end
    rawset(env, "file", setmetatable({
        Find = virtualFind,
        Exists = function(path, pathId)
            local clean = sourcePath(path)
            if (pathId == 'LUA' or pathId == 'lsv' or pathId == 'lcl' or pathId == 'GAME')
                and clean and sources[clean] ~= nil then return true end
            return file.Exists(path, pathId)
        end,
        Read = function(path, pathId)
            local clean = sourcePath(path)
            if (pathId == 'LUA' or pathId == 'lsv' or pathId == 'lcl' or pathId == 'GAME')
                and clean and sources[clean] ~= nil then return sources[clean] end
            return file.Read(path, pathId)
        end,
        IsDir = function(path, pathId)
            local clean = sourcePath(path)
            if (pathId == 'LUA' or pathId == 'lsv' or pathId == 'lcl' or pathId == 'GAME') and clean then
                local prefix = clean:gsub('/$', '') .. '/'
                for sourceName in pairs(sources) do
                    if sourceName:sub(1, #prefix) == prefix then return true end
                end
            end
            return file.IsDir(path, pathId)
        end
    }, { __index = file }))

    rawset(env, "hook", setmetatable({
        Add = function(event, id, fn)
            hook.Add(event, id, fn)
            scope.hooks[#scope.hooks + 1] = { event, id }
        end,
        Remove = function(event, id) hook.Remove(event, id) end
    }, { __index = hook }))

    rawset(env, "timer", setmetatable({
        Create = function(name, delay, count, fn)
            timer.Create(name, delay, count, fn)
            scope.timers[#scope.timers + 1] = name
        end,
        Simple = function(delay, fn)
            scope.counter = scope.counter + 1
            local name = 'elr_' .. scope.name .. '_' .. scope.counter
            timer.Create(name, delay, 1, fn)
            scope.timers[#scope.timers + 1] = name
        end,
        Remove = function(name) timer.Remove(name) end
    }, { __index = timer }))

    rawset(env, "concommand", setmetatable({
        Add = function(name, fn, complete, help, flags)
            concommand.Add(name, fn, complete, help, flags)
            scope.commands[#scope.commands + 1] = name
        end,
        Remove = function(name) concommand.Remove(name) end
    }, { __index = concommand }))

    rawset(env, "net", setmetatable({
        Receive = function(name, fn)
            net.Receive(name, fn)
            scope.receivers[#scope.receivers + 1] = name
        end
    }, { __index = net }))

    if CLIENT then
        rawset(env, "vgui", setmetatable({
            Create = function(class, parent, name)
                local pnl = vgui.Create(class, parent, name)
                if not IsValid(parent) and IsValid(pnl) then
                    scope.panels[#scope.panels + 1] = pnl
                end
                return pnl
            end
        }, { __index = vgui }))
    end

    return env, run
end

local function autoPaths(compiled)
    local result = {}
    for path in pairs(compiled) do
        if path:match('^autorun/[^/]+%.lua$') or
            (SERVER and path:match('^autorun/server/[^/]+%.lua$')) or
            (CLIENT and path:match('^autorun/client/[^/]+%.lua$')) then
            result[#result + 1] = path
        end
    end
    table.sort(result)
    return result
end

local function registerEntities(scope, compiled, env, run)
    local classes = { weapons = {}, entities = {} }
    for path in pairs(compiled) do
        local category, classname, filename = path:match('^(weapons)/([^/]+)/([^/]+%.lua)$')
        if not category then category, classname, filename = path:match('^(entities)/([^/]+)/([^/]+%.lua)$') end
        if category and classname then
            classes[category][classname] = classes[category][classname] or {}
            classes[category][classname][filename] = path
        end
        local kind, solo = path:match('^(weapons)/([^/]+)%.lua$')
        if not kind then kind, solo = path:match('^(entities)/([^/]+)%.lua$') end
        if kind and solo then
            classes[kind][solo] = classes[kind][solo] or {}
            classes[kind][solo]['single.lua'] = path
        end
    end
    for category, list in pairs(classes) do
        local names = {}
        for name in pairs(list) do names[#names + 1] = name end
        table.sort(names)
        for _, name in ipairs(names) do
            local paths = list[name]
            local previousSWEP, previousENT = rawget(env, 'SWEP'), rawget(env, 'ENT')
            rawset(env, 'SWEP', {})
            rawset(env, 'ENT', {})
            if paths['single.lua'] then
                run(paths['single.lua'])
            else
                if paths['shared.lua'] then run(paths['shared.lua']) end
                if SERVER and paths['init.lua'] then run(paths['init.lua']) end
                if CLIENT and paths['cl_init.lua'] then run(paths['cl_init.lua']) end
            end
            if category == 'weapons' then
                local sw = rawget(env, 'SWEP')
                if next(sw) then
                    sw.Base = sw.Base or 'weapon_base'
                    weapons.Register(sw, name)
                end
            else
                local ent = rawget(env, 'ENT')
                if next(ent) then
                    ent.Base = ent.Base or 'base_anim'
                    scripted_ents.Register(ent, name)
                end
            end
            rawset(env, 'SWEP', previousSWEP)
            rawset(env, 'ENT', previousENT)
        end
    end
end

function R.Apply(snapshot)
    if type(snapshot) ~= 'table' or type(snapshot.name) ~= 'string' or type(snapshot.files) ~= 'table' then
        return false, 'Snapshot invalide'
    end
    if not snapshot.name:match('^[%w_-]+$') then return false, 'Nom interdit' end
    local name = snapshot.name
    local old = R.loaded[name]
    if old and tostring(old.version) == tostring(snapshot.version) then return true end

    local compiled, sources = {}, {}
    for _, fileInfo in ipairs(snapshot.files) do
        local path = norm(fileInfo.path)
        if path and path:match('%.lua$') and type(fileInfo.code) == 'string' then
            sources[path] = fileInfo.code
            local fn = CompileString(fileInfo.code, 'elr/' .. name .. '/' .. path, false)
            if type(fn) ~= 'function' then
                local err = tostring(fn)
                ErrorNoHalt('[ELR] Syntaxe invalide ; ancienne version conservee : ' .. err .. '\n')
                return false, err
            end
            compiled[path] = fn
        end
    end
    local scope = {
        name = name, version = snapshot.version,
        hooks = {}, timers = {}, commands = {}, receivers = {}, panels = {}, counter = 0
    }
    if old then cleanup(old) end
    local env, run = makeEnvironment(scope, compiled, sources)
    local ok, err = xpcall(function()
        for _, path in ipairs(autoPaths(compiled)) do run(path) end
        registerEntities(scope, compiled, env, run)
    end, debug.traceback)
    if not ok then
        cleanup(scope)
        ErrorNoHalt('[ELR] Erreur de chargement ' .. name .. ': ' .. tostring(err) .. '\n')
        -- No generic rollback of a script that has already changed global state.
        R.loaded[name] = nil
        if old and old.snapshot then
            local restored = R.Apply(old.snapshot)
            if restored then print('[ELR] Retour a la derniere version valide : ' .. name) end
        end
        return false, err
    end
    scope.snapshot = snapshot
    R.loaded[name] = scope
    print(('[ELR] %s charge : %d fichiers Lua (%s)'):format(name, table.Count(sources), SERVER and 'serveur' or 'client'))
    return true
end
